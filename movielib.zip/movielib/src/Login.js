import React from 'react';


function Login() {

    return (
        <>
            <div class="container">
                <div class="img">
                    <img src="/bg.svg" alt='' />
                </div>
                <div class="login-content">
                    <form action="/movies">
                        <img src="/avatar.svg" alt='' />
                        <h2 class="title">Welcome</h2>
                        <div class="input-div one">
                            <div class="i">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="div">

                                <input type="text" class="input" placeholder='Username' required />
                            </div>
                        </div>
                        <div class="input-div pass">
                            <div class="i">
                                <i class="fas fa-lock"></i>
                            </div>
                            <div class="div">

                                <input type="password" class="input" placeholder='Password' required />
                            </div>
                        </div>
                        <a href="#">Forgot Password?</a>
                        <input type="submit" class="btn" value="Login" />
                    </form>
                </div>
            </div>
        </>
    );
}

export default Login;
