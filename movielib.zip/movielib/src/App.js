import React from 'react';
import { Routes, Route } from 'react-router-dom';
import "./Login.css";
import Login from './Login';
import Error from './Error';
import Result from './Result';

const App = () => {

  return (
    <>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route exact path="/movies" element={<Result />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </>
  );
}
export default App;