import React from 'react'

const Error = () => {
  
  return (
    <>
    <div></div>
      <h1>OOPS Page Not Found !</h1>
    </>
  );
}
export default Error;